package com.syncpoint.compliance.audit;

/** Canonical audit event types (PROJECT_SPEC2 §55). */
public enum AuditEvents {
    LOGIN,
    LOGOUT,
    USER_CREATED,
    USER_ROLE_CHANGED,

    INTEGRATION_CREATED,
    INTEGRATION_CONNECTED,
    INTEGRATION_TESTED,
    INTEGRATION_DISCONNECTED,

    COLLECTION_STARTED,
    COLLECTION_COMPLETED,
    COLLECTION_FAILED,

    EVIDENCE_CREATED,
    EVIDENCE_REVIEWED,
    EVIDENCE_MAPPED,

    AI_ANALYSIS_CREATED,
    EXPORT_CREATED;

    public String code() {
        return name();
    }
}
